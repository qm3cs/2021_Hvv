### 描述
AC集中管理平台存在弱口令漏洞，攻击者可利用该漏洞获取敏感信息。  
fofa title="AC集中管理系统"

### POC & EXP
```
默认弱口令为 admin:admin
```
