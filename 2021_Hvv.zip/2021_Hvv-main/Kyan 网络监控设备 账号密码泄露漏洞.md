### 描述

fofa title="platform - Login"

### POC & EXP
访问url，http://127.0.0.1/hosts ，显示用户名密码  

![2359469-20210418111405992-149165347.png](https://i.loli.net/2021/04/19/h9ynXYtZDC2HvNf.png)
